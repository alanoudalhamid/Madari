﻿using UnityEngine;
using System.Collections;

public static class MaterialUIVersion
{
	public const string currentVersion = "0.2.61";
}
